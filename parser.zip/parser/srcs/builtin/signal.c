/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   signal.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lrasamoe <lrasamoe@student.42antananari    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/09 15:08:25 by lrasamoe          #+#    #+#             */
/*   Updated: 2024/11/21 08:52:01 by lrasamoe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <minishell.h>

void	handle_signal(int sig)
{
	if (sig == SIGINT)
	{
		ft_putstr_fd("\n", 1);
		rl_replace_line("",0);
		rl_on_new_line();
		rl_redisplay();
	}
	g_sig = 128 + sig;
	return ;
}


void	signal_fork(int sig)
{
	if (sig == SIGINT)
		sig += 128;
	close(STDIN_FILENO);
	close(STDOUT_FILENO);
	close(STDERR_FILENO);
	exit(sig);
}

void	my_signal(void)
{
	struct sigaction sa;

	sigemptyset(&sa.sa_mask);
	sa.sa_handler = SIG_IGN;
	sa.sa_flags = 0;
	signal(SIGINT, handle_signal);
	sigaction(SIGQUIT, &sa, NULL);
	
	return ;
}


void	my_signal_heredoc(void)
{
	struct sigaction sa;

	sigemptyset(&sa.sa_mask);
	sa.sa_handler = SIG_IGN;
	sa.sa_flags = 0;
	signal(SIGINT, signal_fork);
	sigaction(SIGQUIT, &sa, NULL);
}