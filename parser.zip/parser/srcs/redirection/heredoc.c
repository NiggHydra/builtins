/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   heredoc.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lrasamoe <lrasamoe@student.42antananari    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/14 12:21:11 by hariandr          #+#    #+#             */
/*   Updated: 2024/11/20 15:34:50 by lrasamoe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <minishell.h>


 int	cmd_here_doc(t_shell *data, t_token *redir_doc)
 {
	char	*str;

	while (1)
	{
		str = readline("> ");
		add_history(str);
		if (str == NULL )
		{
			print_custom_error ("warning: here-document delimited by end-of-file (wanted `");
			ft_putstr_fd (redir_doc->content, 2);
			ft_putendl_fd ("\')", 2);
			break ;
		}
		if (strcmp(str, redir_doc->content) == 0)
		{
			if (str)
				free (str);
			break ;
		}
		else
		{
			write (data->command.here_doc.here_doc[1], str, ft_strlen(str));
			write (data->command.here_doc.here_doc[1], "\n", 1);
		}
		if (str)
			free(str);
	}
	close (data->command.here_doc.here_doc[1]);
	return (0);
 }